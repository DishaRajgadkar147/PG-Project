const config={
    SALT_ROUND:10,
    SECRET:'jdrhdurbvduxcniidjeuissidfieewweur'
}

module.exports=config